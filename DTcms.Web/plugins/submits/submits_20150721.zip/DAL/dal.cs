/*
 submits Plugin by www.chenpan.com.cn  by 20141230
*/
using System;
using System.Data;
using System.Text;
using System.Collections.Generic;
using System.Data.SqlClient;
using DTcms.DBUtility;
using DTcms.Common;
namespace DTcms.Web.Plugin.submits.DAL
{
	/// <summary>
	/// ���ݷ�����:�����ύ
	/// </summary>
	public partial class submits
	{
        private string databaseprefix; //���ݿ����ǰ׺
        public submits(string _databaseprefix)
		{
            databaseprefix = _databaseprefix;
        }

		#region  Method
		/// <summary>
		/// �Ƿ���ڸü�¼
		/// </summary>
		public bool Exists(int id)
		{
			StringBuilder strSql=new StringBuilder();
            strSql.Append("select count(1) from " + databaseprefix + "submits");
			strSql.Append(" where id=@id");
			SqlParameter[] parameters = {
					new SqlParameter("@id", SqlDbType.Int,4)};
			parameters[0].Value = id;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}

		/// <summary>
		/// ����һ������
		/// </summary>
		public int Add(Model.submits model)
		{
			StringBuilder strSql=new StringBuilder();
            strSql.Append("insert into " + databaseprefix + "submits(");
            strSql.Append("title,content,user_name,user_tel,user_qq,user_email,add_time,is_lock)");
			strSql.Append(" values (");
            strSql.Append("@title,@content,@user_name,@user_tel,@user_qq,@user_email,@add_time,@is_lock)");
			strSql.Append(";select @@IDENTITY");
            strSql.Append(";set @ReturnValue=@@IDENTITY");
			SqlParameter[] parameters = {
					new SqlParameter("@title", SqlDbType.NVarChar,100),
					new SqlParameter("@content", SqlDbType.NText),
					new SqlParameter("@user_name", SqlDbType.NVarChar,50),
					new SqlParameter("@user_tel", SqlDbType.NVarChar,30),
					new SqlParameter("@user_qq", SqlDbType.NVarChar,30),
					new SqlParameter("@user_email", SqlDbType.NVarChar,100),
					new SqlParameter("@add_time", SqlDbType.DateTime),
                    new SqlParameter("@is_lock", SqlDbType.TinyInt,1),
                    new SqlParameter("@ReturnValue",SqlDbType.Int)};
			parameters[0].Value = model.title;
			parameters[1].Value = model.content;
			parameters[2].Value = model.user_name;
			parameters[3].Value = model.user_tel;
			parameters[4].Value = model.user_qq;
			parameters[5].Value = model.user_email;
			parameters[6].Value = model.add_time;
            parameters[7].Value = model.is_lock;
            parameters[8].Direction = ParameterDirection.Output;


            List<CommandInfo> sqllist = new List<CommandInfo>();
            CommandInfo cmd = new CommandInfo(strSql.ToString(), parameters);
            sqllist.Add(cmd);

            //������չ�ֶ�
            if (model.fields != null)
            {
                StringBuilder strSql2 = new StringBuilder();
                StringBuilder strFieldName = new StringBuilder(); //�ֶ��б�
                StringBuilder strFieldVar = new StringBuilder(); //�ֶ�����
                SqlParameter[] parameters2 = new SqlParameter[model.fields.Count + 1];
                int i = 1;
                strFieldName.Append("submits_id");
                strFieldVar.Append("@submits_id");
                parameters2[0] = new SqlParameter("@submits_id", SqlDbType.Int, 4);
                parameters2[0].Direction = ParameterDirection.InputOutput;
                foreach (KeyValuePair<string, string> kvp in model.fields)
                {
                    strFieldName.Append("," + kvp.Key);
                    strFieldVar.Append(",@" + kvp.Key);
                    if (kvp.Value.Length <= 4000)
                    {
                        parameters2[i] = new SqlParameter("@" + kvp.Key, SqlDbType.NVarChar, kvp.Value.Length);
                    }
                    else
                    {
                        parameters2[i] = new SqlParameter("@" + kvp.Key, SqlDbType.NText);
                    }

                    parameters2[i].Value = kvp.Value;
                    i++;
                }
                strSql2.Append("insert into " + databaseprefix + "submits_value(");
                strSql2.Append(strFieldName.ToString() + ")");
                strSql2.Append(" values (");
                strSql2.Append(strFieldVar.ToString() + ")");
                cmd = new CommandInfo(strSql2.ToString(), parameters2);
                sqllist.Add(cmd);
            }
            DbHelperSQL.ExecuteSqlTranWithIndentity(sqllist);
            string str = parameters[8].Value.ToString();
            return (int)parameters[8].Value;


		}

        /// <summary>
        /// �޸�һ������
        /// </summary>
        public void UpdateField(int id, string strValue)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("update " + databaseprefix + "submits set " + strValue);
            strSql.Append(" where id=" + id);
            DbHelperSQL.ExecuteSql(strSql.ToString());
        }

        /// <summary>
        /// ����һ������
        /// </summary>
        public bool Update(Model.submits model)
        {
          using (SqlConnection conn = new SqlConnection(DbHelperSQL.connectionString))
            {
                conn.Open();
                using (SqlTransaction trans = conn.BeginTransaction())
                {
                  try
                  {
                    StringBuilder strSql = new StringBuilder();
                    strSql.Append("update " + databaseprefix + "submits set ");
                    strSql.Append("title=@title,");
                    strSql.Append("content=@content,");
                    strSql.Append("user_name=@user_name,");
                    strSql.Append("user_tel=@user_tel,");
                    strSql.Append("user_qq=@user_qq,");
                    strSql.Append("user_email=@user_email,");
                    strSql.Append("add_time=@add_time,");
                    strSql.Append("reply_content=@reply_content,");
                    strSql.Append("reply_time=@reply_time,");
                    strSql.Append("is_lock=@is_lock");
                    strSql.Append(" where id=@id");
                    SqlParameter[] parameters = {
					        new SqlParameter("@title", SqlDbType.NVarChar,100),
					        new SqlParameter("@content", SqlDbType.NText),
					        new SqlParameter("@user_name", SqlDbType.NVarChar,50),
					        new SqlParameter("@user_tel", SqlDbType.NVarChar,30),
					        new SqlParameter("@user_qq", SqlDbType.NVarChar,30),
					        new SqlParameter("@user_email", SqlDbType.NVarChar,100),
					        new SqlParameter("@add_time", SqlDbType.DateTime),
					        new SqlParameter("@reply_content", SqlDbType.NText),
					        new SqlParameter("@reply_time", SqlDbType.DateTime),
					        new SqlParameter("@is_lock", SqlDbType.TinyInt,1),
					        new SqlParameter("@id", SqlDbType.Int,4)};
                    parameters[0].Value = model.title;
                    parameters[1].Value = model.content;
                    parameters[2].Value = model.user_name;
                    parameters[3].Value = model.user_tel;
                    parameters[4].Value = model.user_qq;
                    parameters[5].Value = model.user_email;
                    parameters[6].Value = model.add_time;
                    parameters[7].Value = model.reply_content;
                    parameters[8].Value = model.reply_time;
                    parameters[9].Value = model.is_lock;
                    parameters[10].Value = model.id;
                    DbHelperSQL.ExecuteSql(conn, trans, strSql.ToString(), parameters);        
                    //�޸���չ�ֶ�
                    if (model.fields.Count > 0)
                    {
                        StringBuilder strSql2 = new StringBuilder();
                        StringBuilder strFieldName = new StringBuilder(); //�ֶ��б�
                        SqlParameter[] parameters2 = new SqlParameter[model.fields.Count + 1];
                        int i = 0;
                        foreach (KeyValuePair<string, string> kvp in model.fields)
                        {
                            strFieldName.Append(kvp.Key + "=@" + kvp.Key + ",");
                            if (kvp.Value.Length <= 4000)
                            {
                                parameters2[i] = new SqlParameter("@" + kvp.Key, SqlDbType.NVarChar, kvp.Value.Length);
                            }
                            else
                            {
                                parameters2[i] = new SqlParameter("@" + kvp.Key, SqlDbType.NText);
                            }
                            parameters2[i].Value = kvp.Value;
                            i++;
                        }
                        strSql2.Append("update " + databaseprefix + "submits_value set ");
                        strSql2.Append(Utils.DelLastComma(strFieldName.ToString()));
                        strSql2.Append(" where submits_id=@submits_id");
                        parameters2[i] = new SqlParameter("@submits_id", SqlDbType.Int, 4);
                        parameters2[i].Value = model.id;
                        DbHelperSQL.ExecuteSql(conn, trans, strSql2.ToString(), parameters2);
                    }


                    trans.Commit();
                    }
                    catch
                    {
                        trans.Rollback();
                        return false;
                    }
                }
            }
                        return true;
        }
                       

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public bool Delete(int id)
		{

            //ɾ����չ�ֶα�
            StringBuilder strSql1 = new StringBuilder();
            strSql1.Append("delete from " + databaseprefix + "submits_value ");
            strSql1.Append(" where submits_id=@submits_id ");
            SqlParameter[] parameters1 = {
					new SqlParameter("@submits_id", SqlDbType.Int,4)};
            parameters1[0].Value = id;
            List<CommandInfo> sqllist = new List<CommandInfo>();
            CommandInfo cmd = new CommandInfo(strSql1.ToString(), parameters1);
            sqllist.Add(cmd);

            //ɾ������
            StringBuilder strSql = new StringBuilder();
            strSql.Append("delete from " + databaseprefix + "submits ");
            strSql.Append(" where id=@id");
            SqlParameter[] parameters = {
					new SqlParameter("@id", SqlDbType.Int,4)};
            parameters[0].Value = id;
            cmd = new CommandInfo(strSql.ToString(), parameters);
            sqllist.Add(cmd);

            int rowsAffected = DbHelperSQL.ExecuteSqlTran(sqllist);
            if (rowsAffected > 0)
            {
				return true;
			}
			else
			{
				return false;
			}
		}

        /// <summary>
        /// �õ�һ������ʵ��
        /// </summary>
        public Model.submits   GetModel(int id)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select  top 1 id,title,content,user_name,user_tel,user_qq,user_email,add_time,reply_content,reply_time,is_lock from " + databaseprefix + "submits ");
            strSql.Append(" where id=@id");
            SqlParameter[] parameters = {
					new SqlParameter("@id", SqlDbType.Int,4)};
            parameters[0].Value = id;

            Model.submits model = new Model.submits();
            DataSet ds = DbHelperSQL.Query(strSql.ToString(), parameters);
            if (ds.Tables[0].Rows.Count > 0)
            {
                if (ds.Tables[0].Rows[0]["id"] != null && ds.Tables[0].Rows[0]["id"].ToString() != "")
                {
                    model.id = int.Parse(ds.Tables[0].Rows[0]["id"].ToString());
                }
                if (ds.Tables[0].Rows[0]["title"] != null && ds.Tables[0].Rows[0]["title"].ToString() != "")
                {
                    model.title = ds.Tables[0].Rows[0]["title"].ToString();
                }
                if (ds.Tables[0].Rows[0]["content"] != null && ds.Tables[0].Rows[0]["content"].ToString() != "")
                {
                    model.content = ds.Tables[0].Rows[0]["content"].ToString();
                }
                if (ds.Tables[0].Rows[0]["user_name"] != null && ds.Tables[0].Rows[0]["user_name"].ToString() != "")
                {
                    model.user_name = ds.Tables[0].Rows[0]["user_name"].ToString();
                }
                if (ds.Tables[0].Rows[0]["user_tel"] != null && ds.Tables[0].Rows[0]["user_tel"].ToString() != "")
                {
                    model.user_tel = ds.Tables[0].Rows[0]["user_tel"].ToString();
                }
                if (ds.Tables[0].Rows[0]["user_qq"] != null && ds.Tables[0].Rows[0]["user_qq"].ToString() != "")
                {
                    model.user_qq = ds.Tables[0].Rows[0]["user_qq"].ToString();
                }
                if (ds.Tables[0].Rows[0]["user_email"] != null && ds.Tables[0].Rows[0]["user_email"].ToString() != "")
                {
                    model.user_email = ds.Tables[0].Rows[0]["user_email"].ToString();
                }
                if (ds.Tables[0].Rows[0]["add_time"] != null && ds.Tables[0].Rows[0]["add_time"].ToString() != "")
                {
                    model.add_time = DateTime.Parse(ds.Tables[0].Rows[0]["add_time"].ToString());
                }
                if (ds.Tables[0].Rows[0]["reply_content"] != null && ds.Tables[0].Rows[0]["reply_content"].ToString() != "")
                {
                    model.reply_content = ds.Tables[0].Rows[0]["reply_content"].ToString();
                }
                if (ds.Tables[0].Rows[0]["reply_time"] != null && ds.Tables[0].Rows[0]["reply_time"].ToString() != "")
                {
                    model.reply_time = DateTime.Parse(ds.Tables[0].Rows[0]["reply_time"].ToString());
                }
                if (ds.Tables[0].Rows[0]["is_lock"] != null && ds.Tables[0].Rows[0]["is_lock"].ToString() != "")
                {
                    model.is_lock = int.Parse(ds.Tables[0].Rows[0]["is_lock"].ToString());
                }
                #region ��չ�ֶ���Ϣ==================
                //��ѯ��Ƶ������չ�ֶ�����
                DataTable dt = new submits_field(databaseprefix).GetList("").Tables[0];
                if (dt.Rows.Count > 0)
                {
                    StringBuilder sb = new StringBuilder();
                    foreach (DataRow dr in dt.Rows)
                    {
                        sb.Append(dr["name"].ToString() + ",");
                    }
                    StringBuilder strSql2 = new StringBuilder();
                    strSql2.Append("select top 1 " + Utils.DelLastComma(sb.ToString()) + " from " + databaseprefix + "submits_value ");
                    strSql2.Append(" where submits_id=@submits_id ");
                    SqlParameter[] parameters2 = {
					    new SqlParameter("@submits_id", SqlDbType.Int,4)};
                    parameters2[0].Value = id;

                    DataSet ds2 = DbHelperSQL.Query(strSql2.ToString(), parameters2);
                    if (ds2.Tables[0].Rows.Count > 0)
                    {
                        Dictionary<string, string> dic = new Dictionary<string, string>();
                        foreach (DataRow dr in dt.Rows)
                        {
                            if (ds2.Tables[0].Rows[0][dr["name"].ToString()] != null)
                            {
                                dic.Add(dr["name"].ToString(), ds2.Tables[0].Rows[0][dr["name"].ToString()].ToString());
                            }
                            else
                            {
                                dic.Add(dr["name"].ToString(), "");
                            }
                        }
                        model.fields = dic;
                    }
                }

                #endregion

                return model;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// ���ǰ��������
        /// </summary>
        public DataSet GetList(int Top, string strWhere)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select ");
            if (Top > 0)
            {
                strSql.Append(" top " + Top.ToString());
            }
            strSql.Append(" a.id, a.title,a.content,a.reply_content, a.user_name,a.user_tel,a.user_qq,a.user_email,a.reply_time,a.is_lock,b.* FROM " + databaseprefix + "submits as a left join " + databaseprefix + "submits_value as b on a.id=b.submits_id ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            strSql.Append(" order by b.add_time desc");
            return DbHelperSQL.Query(strSql.ToString());
        }

        /// <summary>
        /// ��ò�ѯ��ҳ����
        /// </summary>
        public DataSet GetList(int pageSize, int pageIndex, string strWhere, string filedOrder, out int recordCount)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select a.id,a.title,a.content,a.user_name,a.user_tel,a.user_qq,a.user_email,a.reply_content,a.reply_time,a.is_lock,b.* FROM " + databaseprefix + "submits as a left join " + databaseprefix + "submits_value as b on a.id=b.submits_id ");
            if (strWhere.Trim() != "")
            {
                strSql.Append(" where " + strWhere);
            }
            recordCount = Convert.ToInt32(DbHelperSQL.GetSingle(PagingHelper.CreateCountingSql(strSql.ToString())));
            return DbHelperSQL.Query(PagingHelper.CreatePagingSql(recordCount, pageSize, pageIndex, strSql.ToString(), filedOrder));
        }

		#endregion  Method
	}
}

